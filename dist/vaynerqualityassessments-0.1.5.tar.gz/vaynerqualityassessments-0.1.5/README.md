# Vayner Quality Assessments
A small demo library for a Medium publication about publishing libraries.

### Installation
```
pip install vaynerqualityassessments
```